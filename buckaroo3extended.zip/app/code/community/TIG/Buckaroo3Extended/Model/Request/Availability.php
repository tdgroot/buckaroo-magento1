<?php
class TIG_Buckaroo3Extended_Model_Request_Availability extends TIG_Buckaroo3Extended_Model_Abstract
{
    public static $allowedCurrencies = array(
		'EUR',
		'GBP',
		'USD',
		'CAD',
		'SHR',
		'NOK',
		'SEK',
		'DKK',
        'ARS',
        'BRL',
        'HRK',
        'LTL',
        'TRY',
        'TRL',
        'AUD',
        'CNY',
        'LVL',
        'MXN',
        'MXP',
        'PLN',
        'CHF',
	);

    /**
     * Various checks to determine if Buckaroo payment options should be available to customers
     *
     * @param boolean $soap
     */
    public static function canUseBuckaroo($soap = false)
    {
    	$return = false;

    	$configValues    = self::_checkConfigValues($soap);

    	$currencyAllowed = self::_checkCurrencyAllowed();

    	$ipAllowed       = self::_checkIpAllowed();

    	$ipV6            = self::_checkIPv6($soap);

    	$isZeroPayment   = self::_checkGrandTotalNotZero();

    	$isEnterprise    = @mage::getModel('Enterprise_Reward_Model_Reward');

    	if (
    	    $configValues        === true
    	    && $currencyAllowed  === true
    	    && $ipAllowed        === true
    	    && $ipV6             === false
    	    && (
    	        $isZeroPayment   === false || $isEnterprise
    	        )
    	)
    	{
    	    $return = true;
    	}
    	return $return;
    }

    /**
     * Checks if all required configuration options are set
     * NOTE: does not check if entered values are valid, only that they're not empty
     *
     * @param boolean $soap
     */
    private static function _checkConfigValues()
    {
        $configValues = false;

        //config values that need to be entered
    	$configEnabled = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended/active', Mage::app()->getStore()->getStoreId());
    	$merchantKeyEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended/key', Mage::app()->getStore()->getStoreId());
    	$thumbprintEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended/thumbprint', Mage::app()->getStore()->getStoreId());
    	$orderStatusSuccessEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended/order_status_success', Mage::app()->getStore()->getStoreId());
    	$orderStatusFailedEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended/order_status_failed', Mage::app()->getStore()->getStoreId());

    	//advanced config values that need to be entered
    	$newOrderStatusEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended_advanced/order_status', Mage::app()->getStore()->getStoreId());
    	$orderStateSuccessEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended_advanced/order_state_success', Mage::app()->getStore()->getStoreId());
    	$orderStateFailedEntered = (bool) Mage::getStoreConfig('buckaroo/buckaroo3extended_advanced/order_state_failed', Mage::app()->getStore()->getStoreId());

    	if ($configEnabled
    		&& $merchantKeyEntered
    		&& $thumbprintEntered
    		&& $orderStatusSuccessEntered
    		&& $orderStatusFailedEntered
    		&& $newOrderStatusEntered
    		&& $orderStateSuccessEntered
    		&& $orderStateFailedEntered
    	)
    	{
    	    $configValues = true;
    	}
    	return $configValues;
    }

    /**
     * Checks if the store's base currency is allowed by Buckaroo
     * Buckaroo 2012 payment module uses the base currency for payments, however Buckaroo does not accept all currencies
     */
    private static function _checkCurrencyAllowed()
    {
        $allowed = false;

    	$baseCurrency = Mage::app()->getStore()->getBaseCurrency()->getCode();

    	if (in_array($baseCurrency, self::$allowedCurrencies)) {
    	    $allowed = true;
    	}

    	return $allowed;
    }

    /**
     * If the 'limit by IP' options is set in the backend, check if the user's IP ids allowed
     * NOTE: this is only the general limit by ip option. Individual module's limit by IP options are not checked here
     */
    private static function _checkIpAllowed()
    {
        $ipAllowed = false;

        if (mage::getStoreConfig('dev/restrict/allow_ips') && Mage::getStoreConfig('buckaroo/buckaroo3extended/limit_by_ip'))
    	{
    		$allowedIp = explode(',', mage::getStoreConfig('dev/restrict/allow_ips'));
    		if (in_array($_SERVER['REMOTE_ADDR'], $allowedIp))
    		{
    			$ipAllowed = true;
    		}
    	} else {
    		$ipAllowed = true;
    	}

    	return $ipAllowed;
    }

    /**
     * Check if the user uses an IPv6 IP-address. This is currently not supported by SOAP payment options
     *
     * @param boolean $soap
     */
    private static function _checkIPv6($soap)
    {
        $IPv6 = true;

    	if ($soap) {
    		$regex = "/(:){2,}/";
    		if (preg_match($regex, $_SERVER['REMOTE_ADDR'])) {
    			$isIpv6 = true;
    		} else {
    			$isIpv6 = false;
    		}
    	} else {
    		$isIpv6 = false;
    	}

    	return $isIpv6;
    }

    /**
     * Checks if the order base grandtotal is zero.
     * NOTE: this check is currently not used. Will be implemented later when I know for certain which payment methods can and cannot handle
     * zero-grandtotal payments.
     */
    private static function _checkGrandTotalNotZero()
    {
        $isZero = false;

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        if ($quote->getBaseGrandTotal() < 0.01) {
            $isZero = true;
        }

        return $isZero;
    }
}